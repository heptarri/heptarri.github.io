src/03_Bsw/Os/list.o: ../src/03_Bsw/Os/list.c \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/03_Bsw/Os/include/FreeRTOS.h \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/03_Bsw/Os/include/FreeRTOSConfig.h \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/03_Bsw/Os/include/projdefs.h \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/03_Bsw/Os/include/portable.h \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/03_Bsw/Os/include/deprecated_definitions.h \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/03_Bsw/Os/portable/GCC/ARM_CM4F/portmacro.h \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/03_Bsw/Os/include/mpu_wrappers.h \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/03_Bsw/Os/include/list.h

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/03_Bsw/Os/include/FreeRTOS.h:

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/03_Bsw/Os/include/FreeRTOSConfig.h:

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/03_Bsw/Os/include/projdefs.h:

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/03_Bsw/Os/include/portable.h:

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/03_Bsw/Os/include/deprecated_definitions.h:

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/03_Bsw/Os/portable/GCC/ARM_CM4F/portmacro.h:

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/03_Bsw/Os/include/mpu_wrappers.h:

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/03_Bsw/Os/include/list.h:
