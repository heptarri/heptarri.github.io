################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../src/03_Bsw/Os/config/OsTask.c \
../src/03_Bsw/Os/config/cmsis_os.c 

OBJS += \
./src/03_Bsw/Os/config/OsTask.o \
./src/03_Bsw/Os/config/cmsis_os.o 

C_DEPS += \
./src/03_Bsw/Os/config/OsTask.d \
./src/03_Bsw/Os/config/cmsis_os.d 


# Each subdirectory must supply rules for building sources it contributes
src/03_Bsw/Os/config/%.o: ../src/03_Bsw/Os/config/%.c
	@echo 'Building file: $<'
	@echo 'Invoking: Standard S32DS C Compiler'
	arm-none-eabi-gcc "@src/03_Bsw/Os/config/OsTask.args" -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


