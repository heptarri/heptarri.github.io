################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../src/05_Mcal/clock/clockMan1.c \
../src/05_Mcal/clock/clock_S32K1xx.c 

OBJS += \
./src/05_Mcal/clock/clockMan1.o \
./src/05_Mcal/clock/clock_S32K1xx.o 

C_DEPS += \
./src/05_Mcal/clock/clockMan1.d \
./src/05_Mcal/clock/clock_S32K1xx.d 


# Each subdirectory must supply rules for building sources it contributes
src/05_Mcal/clock/%.o: ../src/05_Mcal/clock/%.c
	@echo 'Building file: $<'
	@echo 'Invoking: Standard S32DS C Compiler'
	arm-none-eabi-gcc "@src/05_Mcal/clock/clockMan1.args" -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


