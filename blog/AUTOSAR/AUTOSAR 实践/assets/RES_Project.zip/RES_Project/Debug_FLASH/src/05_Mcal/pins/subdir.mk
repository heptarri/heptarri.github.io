################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../src/05_Mcal/pins/pin_mux.c \
../src/05_Mcal/pins/pins_driver.c \
../src/05_Mcal/pins/pins_port_hw_access.c 

OBJS += \
./src/05_Mcal/pins/pin_mux.o \
./src/05_Mcal/pins/pins_driver.o \
./src/05_Mcal/pins/pins_port_hw_access.o 

C_DEPS += \
./src/05_Mcal/pins/pin_mux.d \
./src/05_Mcal/pins/pins_driver.d \
./src/05_Mcal/pins/pins_port_hw_access.d 


# Each subdirectory must supply rules for building sources it contributes
src/05_Mcal/pins/%.o: ../src/05_Mcal/pins/%.c
	@echo 'Building file: $<'
	@echo 'Invoking: Standard S32DS C Compiler'
	arm-none-eabi-gcc "@src/05_Mcal/pins/pin_mux.args" -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


