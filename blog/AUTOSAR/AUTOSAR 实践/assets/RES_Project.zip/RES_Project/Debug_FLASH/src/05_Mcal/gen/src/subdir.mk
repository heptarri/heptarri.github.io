################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../src/05_Mcal/gen/src/Dio_Cfg.c \
../src/05_Mcal/gen/src/Mcu_Cfg.c \
../src/05_Mcal/gen/src/Mcu_PBcfg.c \
../src/05_Mcal/gen/src/Port_Cfg.c \
../src/05_Mcal/gen/src/Port_PBcfg.c 

OBJS += \
./src/05_Mcal/gen/src/Dio_Cfg.o \
./src/05_Mcal/gen/src/Mcu_Cfg.o \
./src/05_Mcal/gen/src/Mcu_PBcfg.o \
./src/05_Mcal/gen/src/Port_Cfg.o \
./src/05_Mcal/gen/src/Port_PBcfg.o 

C_DEPS += \
./src/05_Mcal/gen/src/Dio_Cfg.d \
./src/05_Mcal/gen/src/Mcu_Cfg.d \
./src/05_Mcal/gen/src/Mcu_PBcfg.d \
./src/05_Mcal/gen/src/Port_Cfg.d \
./src/05_Mcal/gen/src/Port_PBcfg.d 


# Each subdirectory must supply rules for building sources it contributes
src/05_Mcal/gen/src/%.o: ../src/05_Mcal/gen/src/%.c
	@echo 'Building file: $<'
	@echo 'Invoking: Standard S32DS C Compiler'
	arm-none-eabi-gcc "@src/05_Mcal/gen/src/Dio_Cfg.args" -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


