################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../src/02_Rte/Rte.c 

OBJS += \
./src/02_Rte/Rte.o 

C_DEPS += \
./src/02_Rte/Rte.d 


# Each subdirectory must supply rules for building sources it contributes
src/02_Rte/%.o: ../src/02_Rte/%.c
	@echo 'Building file: $<'
	@echo 'Invoking: Standard S32DS C Compiler'
	arm-none-eabi-gcc "@src/02_Rte/Rte.args" -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


