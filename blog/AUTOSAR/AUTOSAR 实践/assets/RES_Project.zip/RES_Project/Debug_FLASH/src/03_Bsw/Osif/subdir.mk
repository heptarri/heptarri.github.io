################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../src/03_Bsw/Osif/osif_baremetal.c 

OBJS += \
./src/03_Bsw/Osif/osif_baremetal.o 

C_DEPS += \
./src/03_Bsw/Osif/osif_baremetal.d 


# Each subdirectory must supply rules for building sources it contributes
src/03_Bsw/Osif/%.o: ../src/03_Bsw/Osif/%.c
	@echo 'Building file: $<'
	@echo 'Invoking: Standard S32DS C Compiler'
	arm-none-eabi-gcc "@src/03_Bsw/Osif/osif_baremetal.args" -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


