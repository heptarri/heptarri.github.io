################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../src/05_Mcal/modules/Mcu/src/Mcu.c \
../src/05_Mcal/modules/Mcu/src/Mcu_CMU.c \
../src/05_Mcal/modules/Mcu/src/Mcu_CMU_Irq.c \
../src/05_Mcal/modules/Mcu/src/Mcu_CortexM4.c \
../src/05_Mcal/modules/Mcu/src/Mcu_IPW.c \
../src/05_Mcal/modules/Mcu/src/Mcu_IPW_Irq.c \
../src/05_Mcal/modules/Mcu/src/Mcu_PCC.c \
../src/05_Mcal/modules/Mcu/src/Mcu_PMC.c \
../src/05_Mcal/modules/Mcu/src/Mcu_PMC_Irq.c \
../src/05_Mcal/modules/Mcu/src/Mcu_RCM.c \
../src/05_Mcal/modules/Mcu/src/Mcu_RCM_Irq.c \
../src/05_Mcal/modules/Mcu/src/Mcu_SCG.c \
../src/05_Mcal/modules/Mcu/src/Mcu_SIM.c \
../src/05_Mcal/modules/Mcu/src/Mcu_SMC.c 

OBJS += \
./src/05_Mcal/modules/Mcu/src/Mcu.o \
./src/05_Mcal/modules/Mcu/src/Mcu_CMU.o \
./src/05_Mcal/modules/Mcu/src/Mcu_CMU_Irq.o \
./src/05_Mcal/modules/Mcu/src/Mcu_CortexM4.o \
./src/05_Mcal/modules/Mcu/src/Mcu_IPW.o \
./src/05_Mcal/modules/Mcu/src/Mcu_IPW_Irq.o \
./src/05_Mcal/modules/Mcu/src/Mcu_PCC.o \
./src/05_Mcal/modules/Mcu/src/Mcu_PMC.o \
./src/05_Mcal/modules/Mcu/src/Mcu_PMC_Irq.o \
./src/05_Mcal/modules/Mcu/src/Mcu_RCM.o \
./src/05_Mcal/modules/Mcu/src/Mcu_RCM_Irq.o \
./src/05_Mcal/modules/Mcu/src/Mcu_SCG.o \
./src/05_Mcal/modules/Mcu/src/Mcu_SIM.o \
./src/05_Mcal/modules/Mcu/src/Mcu_SMC.o 

C_DEPS += \
./src/05_Mcal/modules/Mcu/src/Mcu.d \
./src/05_Mcal/modules/Mcu/src/Mcu_CMU.d \
./src/05_Mcal/modules/Mcu/src/Mcu_CMU_Irq.d \
./src/05_Mcal/modules/Mcu/src/Mcu_CortexM4.d \
./src/05_Mcal/modules/Mcu/src/Mcu_IPW.d \
./src/05_Mcal/modules/Mcu/src/Mcu_IPW_Irq.d \
./src/05_Mcal/modules/Mcu/src/Mcu_PCC.d \
./src/05_Mcal/modules/Mcu/src/Mcu_PMC.d \
./src/05_Mcal/modules/Mcu/src/Mcu_PMC_Irq.d \
./src/05_Mcal/modules/Mcu/src/Mcu_RCM.d \
./src/05_Mcal/modules/Mcu/src/Mcu_RCM_Irq.d \
./src/05_Mcal/modules/Mcu/src/Mcu_SCG.d \
./src/05_Mcal/modules/Mcu/src/Mcu_SIM.d \
./src/05_Mcal/modules/Mcu/src/Mcu_SMC.d 


# Each subdirectory must supply rules for building sources it contributes
src/05_Mcal/modules/Mcu/src/%.o: ../src/05_Mcal/modules/Mcu/src/%.c
	@echo 'Building file: $<'
	@echo 'Invoking: Standard S32DS C Compiler'
	arm-none-eabi-gcc "@src/05_Mcal/modules/Mcu/src/Mcu.args" -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


