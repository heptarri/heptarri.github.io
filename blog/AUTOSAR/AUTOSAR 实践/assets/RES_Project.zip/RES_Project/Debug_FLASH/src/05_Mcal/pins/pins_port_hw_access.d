src/05_Mcal/pins/pins_port_hw_access.o: \
 ../src/05_Mcal/pins/pins_port_hw_access.c \
 ../src/05_Mcal/pins/pins_port_hw_access.h \
 ../src/05_Mcal/pins/pins_driver.h \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/device_registers.h \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/common/s32_core_cm4.h \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/S32K144/include/S32K144.h \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/S32K144/include/S32K144_features.h \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/devassert.h \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/status.h \
 ../src/05_Mcal/pins/pins_gpio_hw_access.h

../src/05_Mcal/pins/pins_port_hw_access.h:

../src/05_Mcal/pins/pins_driver.h:

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/device_registers.h:

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/common/s32_core_cm4.h:

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/S32K144/include/S32K144.h:

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/S32K144/include/S32K144_features.h:

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/devassert.h:

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/status.h:

../src/05_Mcal/pins/pins_gpio_hw_access.h:
