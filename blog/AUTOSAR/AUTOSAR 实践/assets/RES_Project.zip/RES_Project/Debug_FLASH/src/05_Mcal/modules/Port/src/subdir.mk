################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../src/05_Mcal/modules/Port/src/Port.c \
../src/05_Mcal/modules/Port/src/Port_Ipw.c \
../src/05_Mcal/modules/Port/src/Port_Port_Ci.c 

OBJS += \
./src/05_Mcal/modules/Port/src/Port.o \
./src/05_Mcal/modules/Port/src/Port_Ipw.o \
./src/05_Mcal/modules/Port/src/Port_Port_Ci.o 

C_DEPS += \
./src/05_Mcal/modules/Port/src/Port.d \
./src/05_Mcal/modules/Port/src/Port_Ipw.d \
./src/05_Mcal/modules/Port/src/Port_Port_Ci.d 


# Each subdirectory must supply rules for building sources it contributes
src/05_Mcal/modules/Port/src/%.o: ../src/05_Mcal/modules/Port/src/%.c
	@echo 'Building file: $<'
	@echo 'Invoking: Standard S32DS C Compiler'
	arm-none-eabi-gcc "@src/05_Mcal/modules/Port/src/Port.args" -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


