################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../src/05_Mcal/modules/Det/src/Det.c 

OBJS += \
./src/05_Mcal/modules/Det/src/Det.o 

C_DEPS += \
./src/05_Mcal/modules/Det/src/Det.d 


# Each subdirectory must supply rules for building sources it contributes
src/05_Mcal/modules/Det/src/%.o: ../src/05_Mcal/modules/Det/src/%.c
	@echo 'Building file: $<'
	@echo 'Invoking: Standard S32DS C Compiler'
	arm-none-eabi-gcc "@src/05_Mcal/modules/Det/src/Det.args" -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


