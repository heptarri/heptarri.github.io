src/05_Mcal/pins/pin_mux.o: ../src/05_Mcal/pins/pin_mux.c \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/device_registers.h \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/common/s32_core_cm4.h \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/S32K144/include/S32K144.h \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/S32K144/include/S32K144_features.h \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/devassert.h \
 ../src/05_Mcal/pins/pin_mux.h ../src/05_Mcal/pins/pins_driver.h \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/status.h

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/device_registers.h:

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/common/s32_core_cm4.h:

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/S32K144/include/S32K144.h:

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/S32K144/include/S32K144_features.h:

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/devassert.h:

../src/05_Mcal/pins/pin_mux.h:

../src/05_Mcal/pins/pins_driver.h:

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/status.h:
