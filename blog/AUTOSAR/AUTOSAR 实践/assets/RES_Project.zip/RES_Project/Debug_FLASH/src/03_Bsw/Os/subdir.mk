################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../src/03_Bsw/Os/croutine.c \
../src/03_Bsw/Os/event_groups.c \
../src/03_Bsw/Os/list.c \
../src/03_Bsw/Os/queue.c \
../src/03_Bsw/Os/stream_buffer.c \
../src/03_Bsw/Os/tasks.c \
../src/03_Bsw/Os/timers.c 

OBJS += \
./src/03_Bsw/Os/croutine.o \
./src/03_Bsw/Os/event_groups.o \
./src/03_Bsw/Os/list.o \
./src/03_Bsw/Os/queue.o \
./src/03_Bsw/Os/stream_buffer.o \
./src/03_Bsw/Os/tasks.o \
./src/03_Bsw/Os/timers.o 

C_DEPS += \
./src/03_Bsw/Os/croutine.d \
./src/03_Bsw/Os/event_groups.d \
./src/03_Bsw/Os/list.d \
./src/03_Bsw/Os/queue.d \
./src/03_Bsw/Os/stream_buffer.d \
./src/03_Bsw/Os/tasks.d \
./src/03_Bsw/Os/timers.d 


# Each subdirectory must supply rules for building sources it contributes
src/03_Bsw/Os/%.o: ../src/03_Bsw/Os/%.c
	@echo 'Building file: $<'
	@echo 'Invoking: Standard S32DS C Compiler'
	arm-none-eabi-gcc "@src/03_Bsw/Os/croutine.args" -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


