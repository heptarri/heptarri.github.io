src/05_Mcal/clock/clock_S32K1xx.o: ../src/05_Mcal/clock/clock_S32K1xx.c \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/device_registers.h \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/common/s32_core_cm4.h \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/S32K144/include/S32K144.h \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/S32K144/include/S32K144_features.h \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/devassert.h \
 ../src/05_Mcal/clock/sim_hw_access.h \
 ../src/05_Mcal/clock/scg_hw_access.h \
 ../src/05_Mcal/clock/pcc_hw_access.h \
 ../src/05_Mcal/clock/pmc_hw_access.h \
 ../src/05_Mcal/clock/smc_hw_access.h ../src/05_Mcal/clock/clock.h \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/status.h \
 ../src/05_Mcal/clock/clock_S32K1xx.h \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/05_Mcal/interrupt/interrupt_manager.h

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/device_registers.h:

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/common/s32_core_cm4.h:

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/S32K144/include/S32K144.h:

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/S32K144/include/S32K144_features.h:

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/devassert.h:

../src/05_Mcal/clock/sim_hw_access.h:

../src/05_Mcal/clock/scg_hw_access.h:

../src/05_Mcal/clock/pcc_hw_access.h:

../src/05_Mcal/clock/pmc_hw_access.h:

../src/05_Mcal/clock/smc_hw_access.h:

../src/05_Mcal/clock/clock.h:

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/status.h:

../src/05_Mcal/clock/clock_S32K1xx.h:

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/05_Mcal/interrupt/interrupt_manager.h:
