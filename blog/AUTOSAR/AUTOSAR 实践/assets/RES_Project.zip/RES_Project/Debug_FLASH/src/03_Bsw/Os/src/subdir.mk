################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../src/03_Bsw/Os/src/croutine.c \
../src/03_Bsw/Os/src/event_groups.c \
../src/03_Bsw/Os/src/list.c \
../src/03_Bsw/Os/src/queue.c \
../src/03_Bsw/Os/src/stream_buffer.c \
../src/03_Bsw/Os/src/tasks.c \
../src/03_Bsw/Os/src/timers.c 

OBJS += \
./src/03_Bsw/Os/src/croutine.o \
./src/03_Bsw/Os/src/event_groups.o \
./src/03_Bsw/Os/src/list.o \
./src/03_Bsw/Os/src/queue.o \
./src/03_Bsw/Os/src/stream_buffer.o \
./src/03_Bsw/Os/src/tasks.o \
./src/03_Bsw/Os/src/timers.o 

C_DEPS += \
./src/03_Bsw/Os/src/croutine.d \
./src/03_Bsw/Os/src/event_groups.d \
./src/03_Bsw/Os/src/list.d \
./src/03_Bsw/Os/src/queue.d \
./src/03_Bsw/Os/src/stream_buffer.d \
./src/03_Bsw/Os/src/tasks.d \
./src/03_Bsw/Os/src/timers.d 


# Each subdirectory must supply rules for building sources it contributes
src/03_Bsw/Os/src/%.o: ../src/03_Bsw/Os/src/%.c
	@echo 'Building file: $<'
	@echo 'Invoking: Standard S32DS C Compiler'
	arm-none-eabi-gcc "@src/03_Bsw/Os/src/croutine.args" -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


