src/06_Startup/startup.o: ../src/06_Startup/startup.c \
 ../src/06_Startup/startup.h ../src/06_Startup/device_registers.h \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/common/s32_core_cm4.h \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/S32K144/include/S32K144.h \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/S32K144/include/S32K144_features.h \
 ../src/06_Startup/devassert.h

../src/06_Startup/startup.h:

../src/06_Startup/device_registers.h:

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/common/s32_core_cm4.h:

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/S32K144/include/S32K144.h:

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/S32K144/include/S32K144_features.h:

../src/06_Startup/devassert.h:
