################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../src/06_Startup/startup.c 

OBJS += \
./src/06_Startup/startup.o 

C_DEPS += \
./src/06_Startup/startup.d 


# Each subdirectory must supply rules for building sources it contributes
src/06_Startup/%.o: ../src/06_Startup/%.c
	@echo 'Building file: $<'
	@echo 'Invoking: Standard S32DS C Compiler'
	arm-none-eabi-gcc "@src/06_Startup/startup.args" -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


