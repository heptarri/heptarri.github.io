src/05_Mcal/cpu/Cpu.o: ../src/05_Mcal/cpu/Cpu.c ../src/05_Mcal/cpu/Cpu.h \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/device_registers.h \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/common/s32_core_cm4.h \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/S32K144/include/S32K144.h \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/S32K144/include/S32K144_features.h \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/devassert.h \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/05_Mcal/interrupt/interrupt_manager.h \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/05_Mcal/clock/clock.h \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/status.h \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/05_Mcal/clock/clock_S32K1xx.h \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/S32K144/startup/system_S32K144.h \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/05_Mcal/clock/clockMan1.h \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/05_Mcal/cpu/Cpu.h \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/05_Mcal/pins/pin_mux.h \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/05_Mcal/pins/pins_driver.h \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/03_Bsw/Os/include/FreeRTOS.h \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/03_Bsw/Os/include/FreeRTOSConfig.h \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/03_Bsw/Os/include/projdefs.h \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/03_Bsw/Os/include/portable.h \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/03_Bsw/Os/include/deprecated_definitions.h \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/03_Bsw/Os/portable/GCC/ARM_CM4F/portmacro.h \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/03_Bsw/Os/include/mpu_wrappers.h

../src/05_Mcal/cpu/Cpu.h:

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/device_registers.h:

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/common/s32_core_cm4.h:

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/S32K144/include/S32K144.h:

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/S32K144/include/S32K144_features.h:

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/devassert.h:

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/05_Mcal/interrupt/interrupt_manager.h:

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/05_Mcal/clock/clock.h:

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/status.h:

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/05_Mcal/clock/clock_S32K1xx.h:

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/S32K144/startup/system_S32K144.h:

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/05_Mcal/clock/clockMan1.h:

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/05_Mcal/cpu/Cpu.h:

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/05_Mcal/pins/pin_mux.h:

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/05_Mcal/pins/pins_driver.h:

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/03_Bsw/Os/include/FreeRTOS.h:

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/03_Bsw/Os/include/FreeRTOSConfig.h:

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/03_Bsw/Os/include/projdefs.h:

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/03_Bsw/Os/include/portable.h:

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/03_Bsw/Os/include/deprecated_definitions.h:

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/03_Bsw/Os/portable/GCC/ARM_CM4F/portmacro.h:

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/03_Bsw/Os/include/mpu_wrappers.h:
