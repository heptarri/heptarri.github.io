src/03_Bsw/Osif/osif_baremetal.o: ../src/03_Bsw/Osif/osif_baremetal.c \
 ../src/03_Bsw/Osif/osif.h \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/status.h \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/device_registers.h \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/common/s32_core_cm4.h \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/S32K144/include/S32K144.h \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/S32K144/include/S32K144_features.h \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/devassert.h \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/devassert.h \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/05_Mcal/modules/Base/include/Mcal.h \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/05_Mcal/modules/Base/include/Compiler.h \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/05_Mcal/modules/Base/include/Compiler_Cfg.h \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/05_Mcal/modules/Base/include/CompilerDefinition.h \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/05_Mcal/modules/Base/include/Std_Types.h \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/05_Mcal/modules/Base/include/Platform_Types.h \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/05_Mcal/gen/include/Soc_Ips.h \
 D:/00_KingDrive_Automotive/02_RES/RES_Project/src/05_Mcal/modules/Base/include/Platform_Types.h

../src/03_Bsw/Osif/osif.h:

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/status.h:

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/device_registers.h:

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/common/s32_core_cm4.h:

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/S32K144/include/S32K144.h:

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/S32K144/include/S32K144_features.h:

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/devassert.h:

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/06_Startup/devassert.h:

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/05_Mcal/modules/Base/include/Mcal.h:

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/05_Mcal/modules/Base/include/Compiler.h:

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/05_Mcal/modules/Base/include/Compiler_Cfg.h:

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/05_Mcal/modules/Base/include/CompilerDefinition.h:

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/05_Mcal/modules/Base/include/Std_Types.h:

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/05_Mcal/modules/Base/include/Platform_Types.h:

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/05_Mcal/gen/include/Soc_Ips.h:

D:/00_KingDrive_Automotive/02_RES/RES_Project/src/05_Mcal/modules/Base/include/Platform_Types.h:
