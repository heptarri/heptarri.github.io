################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../src/06_Startup/S32K144/startup/system_S32K144.c 

S_UPPER_SRCS += \
../src/06_Startup/S32K144/startup/startup_S32K144.S 

OBJS += \
./src/06_Startup/S32K144/startup/startup_S32K144.o \
./src/06_Startup/S32K144/startup/system_S32K144.o 

C_DEPS += \
./src/06_Startup/S32K144/startup/system_S32K144.d 


# Each subdirectory must supply rules for building sources it contributes
src/06_Startup/S32K144/startup/%.o: ../src/06_Startup/S32K144/startup/%.S
	@echo 'Building file: $<'
	@echo 'Invoking: Standard S32DS Assembler'
	arm-none-eabi-gcc "@src/06_Startup/S32K144/startup/startup_S32K144.args" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '

src/06_Startup/S32K144/startup/%.o: ../src/06_Startup/S32K144/startup/%.c
	@echo 'Building file: $<'
	@echo 'Invoking: Standard S32DS C Compiler'
	arm-none-eabi-gcc "@src/06_Startup/S32K144/startup/system_S32K144.args" -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


