################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../src/03_Bsw/Os/portable/MemMang/heap_1.c 

OBJS += \
./src/03_Bsw/Os/portable/MemMang/heap_1.o 

C_DEPS += \
./src/03_Bsw/Os/portable/MemMang/heap_1.d 


# Each subdirectory must supply rules for building sources it contributes
src/03_Bsw/Os/portable/MemMang/%.o: ../src/03_Bsw/Os/portable/MemMang/%.c
	@echo 'Building file: $<'
	@echo 'Invoking: Standard S32DS C Compiler'
	arm-none-eabi-gcc "@src/03_Bsw/Os/portable/MemMang/heap_1.args" -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


