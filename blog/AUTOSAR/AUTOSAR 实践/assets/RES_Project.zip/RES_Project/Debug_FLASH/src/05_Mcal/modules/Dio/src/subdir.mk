################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../src/05_Mcal/modules/Dio/src/Dio.c \
../src/05_Mcal/modules/Dio/src/Dio_Gpio.c 

OBJS += \
./src/05_Mcal/modules/Dio/src/Dio.o \
./src/05_Mcal/modules/Dio/src/Dio_Gpio.o 

C_DEPS += \
./src/05_Mcal/modules/Dio/src/Dio.d \
./src/05_Mcal/modules/Dio/src/Dio_Gpio.d 


# Each subdirectory must supply rules for building sources it contributes
src/05_Mcal/modules/Dio/src/%.o: ../src/05_Mcal/modules/Dio/src/%.c
	@echo 'Building file: $<'
	@echo 'Invoking: Standard S32DS C Compiler'
	arm-none-eabi-gcc "@src/05_Mcal/modules/Dio/src/Dio.args" -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


