################################################################################
# Automatically-generated file. Do not edit!
################################################################################

ELF_SRCS := 
LD_SRCS := 
TODISASSEMBLE_SRCS := 
OBJ_SRCS := 
S_SRCS := 
ASM_UPPER_SRCS := 
TOPREPROCESS_SRCS := 
ASM_SRCS := 
C_SRCS := 
O_SRCS := 
S_UPPER_SRCS := 
EXECUTABLES := 
OBJS := 
SECONDARY_FLASH := 
SECONDARY_SIZE := 
C_DEPS := 

# Every subdirectory with source files must be described here
SUBDIRS := \
src/02_Rte \
src/02_Rte/src \
src/03_Bsw/Os/config \
src/03_Bsw/Os/portable/GCC/ARM_CM4F \
src/03_Bsw/Os/portable/MemMang \
src/03_Bsw/Os/src \
src/05_Mcal/gen/src \
src/05_Mcal/modules/Det/src \
src/05_Mcal/modules/Dio/src \
src/05_Mcal/modules/Mcu/src \
src/05_Mcal/modules/Port/src \
src/06_Startup/S32K144/startup \
src/06_Startup \
src \

