/**  ******************************************************************************  * Copyright (c) 2023 ShineAuto.Co.Ltd  * File name : OsTask.h  * Author : zhuzhengchao  * Version: v1.0.0  * Create date: 2024-01-03  * Description : Implementation of OS component task function  * History :  *   <author>       <time>            <version>            <desc>  *   zhuzhengchao   2024-01-03        v1.0.0               initial version  *******************************************************************************/
/* Define to prevent recursive inclusion -------------------------------------*/#ifndef OSTASK_H#define OSTASK_H
/* Public_Includes -----------------------------------------------------------*/#include "cmsis_os.h"
/* Public_TypeRedefinition ---------------------------------------------------*/
/* Public_Prototypes ---------------------------------------------------------*/
/* Public_Macros -------------------------------------------------------------*/
/* Public_Enums --------------------------------------------------------------*/
/* Public_Structs ------------------------------------------------------------*/
/* Public_Variables ----------------------------------------------------------*/extern osThreadId StartUpHandle;extern osThreadId Task1Handle;extern osThreadId Task2Handle;extern osThreadId Task3Handle;extern osThreadId Task4Handle;extern osThreadId Task5Handle;extern osThreadId Task6Handle;
/* Public_Functions ----------------------------------------------------------*//******************************************************************************  * @brief NA  * @param[in] NA  * @param[out] NA  * @return NA******************************************************************************/extern void OsTask_Init(void);
#endif /* _OSTASK_H_ */
/**********************************End of file*********************************/
