/*
 * main implementation: use this 'C' sample to create your own application
 *
 */

#include "OsTask.h"
#include "cmsis_os.h"


int main(void)
{
	OsTask_Init();
	osKernelInitialize();
	osKernelStart();


    return 0;
}
