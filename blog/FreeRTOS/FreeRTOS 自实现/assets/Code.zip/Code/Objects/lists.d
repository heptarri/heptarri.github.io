.\objects\lists.o: LinRTOS Kernel\Lists.c
.\objects\lists.o: .\LinRTOS Kernel\inc\Lists.h
.\objects\lists.o: E:\Users\hepta\AppData\Local\Keil_v5\ARM\ARMCC\Bin\..\include\stdint.h
