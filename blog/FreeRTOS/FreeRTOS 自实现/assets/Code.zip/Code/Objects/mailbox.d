.\objects\mailbox.o: LinRTOS Kernel\Mailbox.c
.\objects\mailbox.o: .\LinRTOS Kernel\inc\Mailbox.h
.\objects\mailbox.o: .\LinRTOS Kernel\inc\Event.h
.\objects\mailbox.o: .\LinRTOS Kernel\inc\Tasks.h
.\objects\mailbox.o: E:\Users\hepta\AppData\Local\Keil_v5\ARM\ARMCC\Bin\..\include\stdint.h
.\objects\mailbox.o: .\LinRTOS Kernel\inc\Bitmap.h
.\objects\mailbox.o: .\LinRTOS Kernel\inc\Lists.h
.\objects\mailbox.o: .\LinRTOS Kernel\inc\LinOSConfig.h
.\objects\mailbox.o: .\LinRTOS Kernel\inc\LinOS.h
.\objects\mailbox.o: E:\Users\hepta\AppData\Local\Keil_v5\ARM\ARMCC\Bin\..\include\string.h
.\objects\mailbox.o: .\LinRTOS Kernel\inc\Sem.h
.\objects\mailbox.o: .\LinRTOS Kernel\inc\Mempool.h
.\objects\mailbox.o: .\LinRTOS Kernel\inc\EventGroup.h
.\objects\mailbox.o: .\LinRTOS Kernel\inc\Mutex.h
.\objects\mailbox.o: .\LinRTOS Kernel\inc\Timer.h
.\objects\mailbox.o: .\LinRTOS Kernel\portable\RVDS\port.h
.\objects\mailbox.o: .\LinRTOS Kernel\portable\portcpu.h
.\objects\mailbox.o: E:\Users\hepta\AppData\Local\Arm\Packs\ARM\Cortex_DFP\1.1.0\Device\ARMCM4\Include\ARMCM4.h
.\objects\mailbox.o: E:\Users\hepta\AppData\Local\Arm\Packs\ARM\CMSIS\5.8.0\CMSIS\Core\Include\core_cm4.h
.\objects\mailbox.o: E:\Users\hepta\AppData\Local\Arm\Packs\ARM\CMSIS\5.8.0\CMSIS\Core\Include\cmsis_version.h
.\objects\mailbox.o: E:\Users\hepta\AppData\Local\Arm\Packs\ARM\CMSIS\5.8.0\CMSIS\Core\Include\cmsis_compiler.h
.\objects\mailbox.o: E:\Users\hepta\AppData\Local\Arm\Packs\ARM\CMSIS\5.8.0\CMSIS\Core\Include\cmsis_armcc.h
.\objects\mailbox.o: E:\Users\hepta\AppData\Local\Arm\Packs\ARM\CMSIS\5.8.0\CMSIS\Core\Include\mpu_armv7.h
.\objects\mailbox.o: E:\Users\hepta\AppData\Local\Arm\Packs\ARM\Cortex_DFP\1.1.0\Device\ARMCM4\Include\system_ARMCM4.h
.\objects\mailbox.o: .\LinRTOS Kernel\inc\LinOS.h
