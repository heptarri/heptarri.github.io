.\objects\tasks.o: LinRTOS Kernel\Tasks.c
.\objects\tasks.o: .\LinRTOS Kernel\inc\Tasks.h
.\objects\tasks.o: E:\Users\hepta\AppData\Local\Keil_v5\ARM\ARMCC\Bin\..\include\stdint.h
.\objects\tasks.o: .\LinRTOS Kernel\inc\Bitmap.h
.\objects\tasks.o: .\LinRTOS Kernel\inc\Lists.h
.\objects\tasks.o: .\LinRTOS Kernel\inc\LinOSConfig.h
.\objects\tasks.o: .\LinRTOS Kernel\portable\RVDS\port.h
.\objects\tasks.o: .\LinRTOS Kernel\portable\portcpu.h
.\objects\tasks.o: E:\Users\hepta\AppData\Local\Arm\Packs\ARM\Cortex_DFP\1.1.0\Device\ARMCM4\Include\ARMCM4.h
.\objects\tasks.o: E:\Users\hepta\AppData\Local\Arm\Packs\ARM\CMSIS\5.8.0\CMSIS\Core\Include\core_cm4.h
.\objects\tasks.o: E:\Users\hepta\AppData\Local\Arm\Packs\ARM\CMSIS\5.8.0\CMSIS\Core\Include\cmsis_version.h
.\objects\tasks.o: E:\Users\hepta\AppData\Local\Arm\Packs\ARM\CMSIS\5.8.0\CMSIS\Core\Include\cmsis_compiler.h
.\objects\tasks.o: E:\Users\hepta\AppData\Local\Arm\Packs\ARM\CMSIS\5.8.0\CMSIS\Core\Include\cmsis_armcc.h
.\objects\tasks.o: E:\Users\hepta\AppData\Local\Arm\Packs\ARM\CMSIS\5.8.0\CMSIS\Core\Include\mpu_armv7.h
.\objects\tasks.o: E:\Users\hepta\AppData\Local\Arm\Packs\ARM\Cortex_DFP\1.1.0\Device\ARMCM4\Include\system_ARMCM4.h
.\objects\tasks.o: .\LinRTOS Kernel\inc\LinOS.h
.\objects\tasks.o: E:\Users\hepta\AppData\Local\Keil_v5\ARM\ARMCC\Bin\..\include\string.h
.\objects\tasks.o: .\LinRTOS Kernel\inc\Sem.h
.\objects\tasks.o: .\LinRTOS Kernel\inc\Event.h
.\objects\tasks.o: .\LinRTOS Kernel\inc\Mailbox.h
.\objects\tasks.o: .\LinRTOS Kernel\inc\Mempool.h
.\objects\tasks.o: .\LinRTOS Kernel\inc\EventGroup.h
.\objects\tasks.o: .\LinRTOS Kernel\inc\Mutex.h
.\objects\tasks.o: .\LinRTOS Kernel\inc\Timer.h
.\objects\tasks.o: .\LinRTOS Kernel\portable\RVDS\port.h
