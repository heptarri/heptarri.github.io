.\objects\bitmap.o: LinRTOS Kernel\Bitmap.c
.\objects\bitmap.o: .\LinRTOS Kernel\inc\Bitmap.h
.\objects\bitmap.o: E:\Users\hepta\AppData\Local\Keil_v5\ARM\ARMCC\Bin\..\include\stdint.h
.\objects\bitmap.o: .\LinRTOS Kernel\inc\Tasks.h
.\objects\bitmap.o: .\LinRTOS Kernel\inc\Lists.h
.\objects\bitmap.o: .\LinRTOS Kernel\inc\LinOSConfig.h
